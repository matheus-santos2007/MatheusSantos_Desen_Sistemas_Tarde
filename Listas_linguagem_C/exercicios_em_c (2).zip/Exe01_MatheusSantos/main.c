/*Faça um programa que receba ao salario de um funcionario, calcule e mostre:
* o salario atual,
 * o valor do aumento e o novo salario,sabendo-se que este sofreu um aumento de 25%.
 */



#include <stdio.h>
 int main() {
  int sal_atual,sal_novo;
  printf("digite o seu salario:");
  scanf("%d*c",&sal_atual);

  sal_novo = sal_atual + sal_atual* (0.25);

  printf("\nSeu novo salario com um aumento de 25 porcento é de: %d",sal_novo);
  printf("\n Matheus Etelvino dos Santos");

 }