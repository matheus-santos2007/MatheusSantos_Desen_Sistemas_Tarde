#include <stdio.h>

int main() {
    int dia, mes;

    printf("Digite o mes de nascimento (1 a 12): ");
    scanf("%d", &mes);

 

    printf("Digite o dia de nascimento: ");
    scanf("%d", &dia);

    

    // Determina o signo
    switch (mes) {
        case 1:
            if (dia < 20)
                printf("Seu signo e Capricornio.\n");
            else
                printf("Seu signo e Aquario.\n");
            break;
        case 2:
            if (dia < 19)
                printf("Seu signo e Aquario.\n");
            else
                printf("Seu signo e Peixes.\n");
            break;
        case 3:
            if (dia < 21)
                printf("Seu signo e Peixes.\n");
            else
                printf("Seu signo e Aries.\n");
            break;
        case 4:
            if (dia < 20)
                printf("Seu signo e Aries.\n");
            else
                printf("Seu signo e Touro.\n");
            break;
        case 5:
            if (dia < 21)
                printf("Seu signo e Touro.\n");
            else
                printf("Seu signo e Gemeos.\n");
            break;
        case 6:
            if (dia < 21)
                printf("Seu signo e Gemeos.\n");
            else
                printf("Seu signo e Cancer.\n");
            break;
        case 7:
            if (dia < 23)
                printf("Seu signo e Cancer.\n");
            else
                printf("Seu signo e Leao.\n");
            break;
        case 8:
            if (dia < 23)
                printf("Seu signo e Leao.\n");
            else
                printf("Seu signo e Virgem.\n");
            break;
        case 9:
            if (dia < 23)
                printf("Seu signo e Virgem.\n");
            else
                printf("Seu signo e Libra.\n");
            break;
        case 10:
            if (dia < 23)
                printf("Seu signo e Libra.\n");
            else
                printf("Seu signo e Escorpiao.\n");
            break;
        case 11:
            if (dia < 22)
                printf("Seu signo e Escorpiao.\n");
            else
                printf("Seu signo e Sagitario.\n");
            break;
        case 12:
            if (dia < 22)
                printf("Seu signo e Sagitario.\n");
            else
                printf("Seu signo e Capricornio.\n");
            break;
    }

    return 0;
}
