#include <stdio.h>

int main() {
    int opcao;
    float salario, imposto, novo_salario;

    printf("===== MENU =====\n");
    printf("1 - Calcular imposto\n");
    printf("2 - Calcular novo salario\n");
    printf("3 - Classificar salario\n");
    printf("Escolha uma opcao: ");
    scanf("%d", &opcao);

    switch(opcao) {
        case 1:
            printf("Digite o salario: R$ ");
            scanf("%f", &salario);

            if (salario < 500) {
                imposto = salario * 0.05;
            } else if (salario <= 850) {
                imposto = salario * 0.10;
            } else {
                imposto = salario * 0.15;
            }

            printf("Imposto a ser pago: R$ %.2f\n", imposto);
            break;

        case 2:
            printf("Digite o salario: R$ ");
            scanf("%f", &salario);

            if (salario > 1500) {
                novo_salario = salario + 25;
            } else if (salario >= 750 && salario <= 1500) {
                novo_salario = salario + 50;
            } else if (salario >= 450 && salario < 750) {
                novo_salario = salario + 75;
            } else {
                novo_salario = salario + 100;
            }

            printf("Novo salario: R$ %.2f\n", novo_salario);
            break;

        case 3:
            printf("Digite o salario: R$ ");
            scanf("%f", &salario);

            if (salario <= 700) {
                printf("Classificacao: Mal remunerado\n");
            } else {
                printf("Classificacao: Bem remunerado\n");
            }
            break;

        default:
            printf("Opcao invalida!\n");
            break;
    }

    printf("\nMatheus Etelvino dos Santos\n");

    return 0;
}
