
#include <stdio.h>

int main()
{
    char ch;
    ch = getchar();
 
    if (ch == 'p')
    printf("Você pressionou a tecla p");

    
    
}
