
#include <stdio.h>

int main()
{
    char ch;
    printf("Digite um letra entre A e Z: ");
    ch = getchar();
    if (ch >= 'A' )
        if(ch <= 'Z')
            printf("Você acertou");
}
