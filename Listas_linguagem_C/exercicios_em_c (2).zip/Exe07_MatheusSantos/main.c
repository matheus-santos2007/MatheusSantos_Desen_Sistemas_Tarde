/*Faça um programa que receba uma medida em pés.faça as conversões a
seguir e mostre os resultados
pé=12 polegadas
1 jarda = 3 pés
1 milha = 1760 jardas*/
#include <stdio.h>

int main()
{
    float polegadas,pes,jardas,milhas;
    
    printf("Digite a medida em pes: ");
    scanf("%f", &pes);
    
    polegadas = pes * 12;
    jardas = pes / 3;
    milhas = jardas / 1760;
    
    printf("Medida em pes: %.2f\n",pes);
    printf("Medida em polegadas: %.2f\n",polegadas);
    printf("Medida em jardas: %.2f\n",jardas);
    printf("Medida em milhas: %.2f\n",milhas);
    printf("Matheus Etelvino dos Santos");
    


    
    return 0;
}