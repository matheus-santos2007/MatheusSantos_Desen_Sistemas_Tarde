/*

EXE 003 - Faça um programa que receba o valor de um depósito
e o valor da taxa de juros, calcule e mostre o valor do rendimento
e o valor total depois do rendimento.
*/
#include <stdio.h>

int main()
{
    float deposito,juros,rendi,total;
    
    printf("Digite o valor de deposito: ");
    scanf("%f",&deposito);
    
    printf("Digite a taxa de juros: ");
    scanf("%f",&juros);
    
    rendi = deposito * (juros/100);
    total = deposito + rendi;
    
    printf("Valor do deposito: R$%.2f\n",deposito);
    printf("Rendimento: R$%2.f\n",juros);
    printf("Total com o rendimento: R$%.2f",total);
    
    

    return 0;
}
