
#include <stdio.h>

int main()
{
    char ch;
    printf("digite uma letra entre A e Z: ");
        ch = getchar();
        if (ch >= 'A' && ch <= 'Z')
        printf("Você acertou");
}
