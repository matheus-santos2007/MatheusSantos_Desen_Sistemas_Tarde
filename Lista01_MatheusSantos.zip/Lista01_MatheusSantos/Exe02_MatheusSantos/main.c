/*EXE 002 - Faça um programa que receba o salário base de um funcionário,
calcule e mostre o salário a receber, sabendo-se que o funcionário tem
gratificação de 5% sobre o salário base e paga imposto de 7% também sobre o salário base.
Faça exibir o valor da gratificação, valor do imposto e o salário a receber.*/


#include <stdio.h>

int main()
{
    float sal_base,grat,impos,receber;
    
    printf("Digite o salario base do funcioanario: ");
    scanf("%f", &sal_base);
    
    grat = sal_base * 0.05;
    
    impos = sal_base * 0.07;
    
    receber = sal_base + grat - impos;
    
    printf("Valor da gratificação: %2.f", grat);
    printf("\nValor da imposto: %2.f", impos);
    printf("\nValor a receber: %2.f", receber);
    
    return 0;
    

}
