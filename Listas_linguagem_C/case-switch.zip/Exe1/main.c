
#include <stdio.h>

int main()
{
    float num1, num2;
    char op;

    printf("Digite o primeiro numero: ");
    scanf("%f", &num1);

    printf("Digite o segundo numero: ");
    scanf("%f", &num2);

    printf("Escolha um operador(+,-,*,/) :");
    scanf(" %c", &op);

    switch(op)
    {
        case '+':
            printf("= %.2f",num1 + num2);
            break;
        case '-':
            printf("= %.2f",num1 - num2);
            break;
        case '*':
            printf("= %.2f",num1 * num2);
            break;
        case '/':
            if(num2 != 0) {
                printf("= %.2f",num1 / num2);
                
            }else {
                printf("Nao pode ser dividido por zero");
                
                
            }
            printf("\nMatheus Etelvino dos Santos");
            



    }



}