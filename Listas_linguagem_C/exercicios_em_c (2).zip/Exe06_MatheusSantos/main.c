/*EXE 006 – Notas e Média Ponderada
Faça um programa que receba TRÊS notas e seus respectivos PESO,
calcule e mostre a MÉDIA PONDERADA.
*/
#include <stdio.h>

int main()
{
    float nt1, nt2, nt3;
    int peso1, peso2, peso3;
    float ponderada;
    
    printf("Digite a primeira nota: ");
    scanf("%f", &nt1);
    printf("Digite o peso da primeira nota: ");
    scanf("%d", &peso1);
    
    printf("Digite a segunda nota: ");
    scanf("%f", &nt2);
    printf("Digite o peso da segunda nota: ");
    scanf("%d", &peso2);
    
    printf("Digite a terceira nota: ");
    scanf("%f", &nt3);
    printf("Digite o peso da terceira nota: ");
    scanf("%d", &peso3);
    
    ponderada = (nt1 * peso1 + nt2 * peso2 + nt3 * peso3) / peso1 + peso2 + peso3;
    
    printf("A media ponderada das notas são: %.2f\n",ponderada);
    
    return 0;
    
}
