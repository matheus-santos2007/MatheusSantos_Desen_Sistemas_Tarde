
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL,"Portuguese");
    int idade;
    printf("Digite sua idade: ");
    scanf("%d",&idade);
    if(idade >= 0  &&  idade<=11) {
        printf("\n Crianca");
        }else if (idade >= 12 && idade<=18){
    printf("\n Adolescente");
    }else if (idade >=19 & idade<=24) {
        printf("\njovem");
    }else if (idade >=25 & idade<=59 ) {
        printf("\nadulto");
    }else if (idade >=60 ) {
        printf("\nIdoso");
    }
    printf("\nMatheus Etelvino dos Santos");


}