#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL,"Portuguese");
    int a, b, c;
    printf("Digite 3 numeros quaisquer: ");
    scanf("%d %d %d", &a, &b, &c);
    if (a > b && a > c){
        printf("\n O maior numero e %d", a);
    }else if (b > a && b > c){
        printf("\n O maior numero e %d", b);
    }else if (c > a && c > b) {
        printf("\n O maior numero e %d",c);
    }else {
        printf("Não ha um unico numero maior(pode haver empate)");
    }
    printf("\nMatheus Etelvino dos Santos");




}