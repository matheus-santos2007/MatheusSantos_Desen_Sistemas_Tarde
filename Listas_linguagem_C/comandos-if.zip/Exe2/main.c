
#include <stdio.h>

int main()
{
    if(getchar()=='p'){
        printf("Você digitou p");
        printf("Pressionou outra tecla");
        getchar();
    }

    
}
