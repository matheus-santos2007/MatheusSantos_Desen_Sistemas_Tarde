/*EXE 005 – Receba 3 Notas e exiba Média
Faça um programa que receba TRÊS notas, calcule e mostre a MÉDIA aritmética.
*/
#include <stdio.h>

int main()
{
    int nt1, nt2, nt3, media;
    
    printf("Digite a primeira nota:\n ");
    scanf("%d", &nt1);
    
    printf("Digite a segunda nota:\n ");
    scanf("%d", &nt2);
    
    printf("Digite a terceira nota:\n ");
    scanf("%d", &nt3);
    
    media = nt1 + nt2 + nt3 / 3;
    
    printf("A media das 3 notas somadas: %d\n");

    return 0;
}
