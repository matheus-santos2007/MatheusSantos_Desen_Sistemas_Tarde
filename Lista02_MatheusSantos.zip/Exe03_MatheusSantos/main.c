#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL,"Portuguese");
    int num1, num2;
    printf("Digite dois numeros quaisquer: ");
    scanf("%d %d", &num1, &num2);

    if (num1 < num2) {
        printf("ordem crescente %d %d", num1, num2);
    }else if (num2 < num1) {
        printf("ordem crescente %d %d", num2, num1);
    }else {
        printf("\nOs numeros sao iguais");
    }
    printf("\nMatheus Etelvino dos Santos");

}